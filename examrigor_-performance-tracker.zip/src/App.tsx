import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  User, 
  Calendar, 
  BookOpen, 
  AlertTriangle, 
  ChevronRight, 
  Settings,
  Clock,
  TrendingUp,
  ListTodo,
  Plus,
  Play,
  Square,
  CheckCircle2,
  XCircle,
  History,
  Brain
} from 'lucide-react';

import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell,
  LineChart,
  Line
} from 'recharts';

interface UserSettings {
  name: string;
  exam_month: string;
  subject_count: number;
  negative_motivation: string;
  daily_goal_hours: number;
  theme?: 'light' | 'dark';
}

interface Task {
  id: number;
  daily_id?: number;
  name: string;
  category: 'core' | 'life';
  type: 'standard' | 'normal';
  standard_minutes?: number;
  is_completed?: boolean;
}

interface Benchmark {
  task_name: string;
  best_seconds: number;
  last_seconds: number;
}

export default function App() {
  const [settings, setSettings] = useState<UserSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [step, setStep] = useState(1);
  const [view, setView] = useState<'tasks' | 'analytics' | 'benchmarks' | 'settings'>('tasks');
  const [tasks, setTasks] = useState<Task[]>([]);
  const [library, setLibrary] = useState<Task[]>([]);
  const [showLibrary, setShowLibrary] = useState(false);
  const [benchmarks, setBenchmarks] = useState<Record<string, Benchmark>>({});
  const [activeTask, setActiveTask] = useState<Task | null>(null);
  const [timer, setTimer] = useState(0);
  const [isOvertime, setIsOvertime] = useState(false);
  const [showOvertimeModal, setShowOvertimeModal] = useState(false);
  const [overtimeReason, setOvertimeReason] = useState('');
  const [todayStats, setTodayStats] = useState({ total_seconds: 0, overtime_count: 0 });
  const [weeklyStats, setWeeklyStats] = useState<any[]>([]);
  const [subjectStats, setSubjectStats] = useState<any[]>([]);
  const [timelineStats, setTimelineStats] = useState<any[]>([]);
  
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Onboarding Form State
  const [formData, setFormData] = useState<UserSettings>({
    name: '',
    exam_month: '',
    subject_count: 1,
    negative_motivation: '',
    daily_goal_hours: 8
  });

  // Task Creation State
  const [newTask, setNewTask] = useState({
    name: '',
    category: 'core' as 'core' | 'life',
    type: 'normal' as 'standard' | 'normal',
    standard_minutes: 30
  });

  useEffect(() => {
    fetchSettings();
    fetchTasks();
    fetchLibrary();
    fetchBenchmarks();
    fetchTodayStats();
    fetchAnalytics();
    
    // Initialize audio for beep
    audioRef.current = new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3');
  }, []);

  const fetchAnalytics = async () => {
    try {
      const [weekly, subjects, timeline] = await Promise.all([
        fetch('/api/stats/weekly').then(r => r.json()),
        fetch('/api/stats/subjects').then(r => r.json()),
        fetch('/api/stats/timeline').then(r => r.json())
      ]);
      setWeeklyStats(weekly);
      setSubjectStats(subjects);
      setTimelineStats(timeline);
    } catch (err) {
      console.error("Failed to fetch analytics", err);
    }
  };

  useEffect(() => {
    if (activeTask && activeTask.type === 'standard' && activeTask.standard_minutes) {
      const standardSeconds = activeTask.standard_minutes * 60;
      if (timer >= standardSeconds && !isOvertime) {
        setIsOvertime(true);
        audioRef.current?.play();
      }
    }
  }, [timer, activeTask, isOvertime]);

  const fetchSettings = async () => {
    try {
      const res = await fetch('/api/settings');
      const data = await res.json();
      if (data) {
        setSettings(data);
        setFormData(data);
      }
    } catch (err) {
      console.error("Failed to fetch settings", err);
    } finally {
      setLoading(false);
    }
  };

  const fetchTasks = async () => {
    const res = await fetch('/api/tasks/today');
    const data = await res.json();
    setTasks(data);
  };

  const fetchLibrary = async () => {
    const res = await fetch('/api/tasks/library');
    const data = await res.json();
    setLibrary(data);
  };

  const fetchBenchmarks = async () => {
    const res = await fetch('/api/benchmarks');
    const data = await res.json();
    const benchMap: Record<string, Benchmark> = {};
    data.forEach((b: Benchmark) => benchMap[b.task_name] = b);
    setBenchmarks(benchMap);
  };

  const fetchTodayStats = async () => {
    const res = await fetch('/api/stats/today');
    const data = await res.json();
    setTodayStats(data || { total_seconds: 0, overtime_count: 0 });
  };

  const handleOnboardingSubmit = async () => {
    try {
      const res = await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });
      if (res.ok) setSettings(formData);
    } catch (err) {
      console.error("Failed to save settings", err);
    }
  };

  const handleAddTask = async () => {
    if (!newTask.name) return;
    const res = await fetch('/api/tasks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newTask)
    });
    if (res.ok) {
      fetchTasks();
      fetchLibrary();
      setNewTask({ ...newTask, name: '' });
    }
  };

  const addToToday = async (task_id: number) => {
    await fetch('/api/tasks/today', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ task_id })
    });
    fetchTasks();
  };

  const removeFromToday = async (daily_id: number) => {
    await fetch(`/api/tasks/today/${daily_id}`, { method: 'DELETE' });
    fetchTasks();
  };

  const startTask = (task: Task) => {
    setActiveTask(task);
    setTimer(0);
    setIsOvertime(false);
    timerRef.current = setInterval(() => {
      setTimer(prev => prev + 1);
    }, 1000);
  };

  const stopTask = async () => {
    if (timerRef.current) clearInterval(timerRef.current);
    
    if (isOvertime) {
      setShowOvertimeModal(true);
    } else {
      await saveLog();
    }
  };

  const saveLog = async () => {
    if (!activeTask) return;
    
    await fetch('/api/logs', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        task_id: activeTask.id,
        daily_id: activeTask.daily_id,
        duration_seconds: timer,
        is_overtime: isOvertime,
        overtime_reason: overtimeReason
      })
    });

    setActiveTask(null);
    setTimer(0);
    setOvertimeReason('');
    setShowOvertimeModal(false);
    fetchBenchmarks();
    fetchTodayStats();
  };

  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    return `${h > 0 ? h + ':' : ''}${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const toggleTheme = async () => {
    if (!settings) return;
    const newTheme = settings.theme === 'light' ? 'dark' : 'light';
    const newSettings = { ...settings, theme: newTheme };
    
    try {
      const res = await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newSettings)
      });
      if (res.ok) setSettings(newSettings as UserSettings);
    } catch (err) {
      console.error("Failed to update theme", err);
    }
  };
  const calculateRemainingProductiveHours = (): string => {
    if (!settings) return "0";
    const goalSeconds = settings.daily_goal_hours * 3600;
    const spentSeconds = todayStats.total_seconds || 0;
    
    // Remaining tasks standard time
    const remainingTasks = tasks.filter(t => !activeTask || t.id !== activeTask.id);
    const remainingStandardSeconds = remainingTasks.reduce((acc, t) => acc + (t.standard_minutes || 0) * 60, 0);
    
    const remaining = goalSeconds - (spentSeconds + remainingStandardSeconds);
    return Math.max(0, remaining / 3600).toFixed(1);
  };

  const handleSaveSettings = async () => {
    try {
      const res = await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });
      if (res.ok) {
        setSettings(formData);
        setView('tasks');
      }
    } catch (err) {
      console.error("Failed to save settings", err);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#151619] flex items-center justify-center">
        <div className="text-white font-mono text-sm animate-pulse tracking-widest">INITIALIZING RIGOR OS...</div>
      </div>
    );
  }

  if (!settings) {
    return (
      <div className="min-h-screen bg-[#151619] text-white font-sans flex items-center justify-center p-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-md w-full bg-[#1c1d21] border border-white/10 rounded-2xl p-8 shadow-2xl"
        >
          <div className="mb-8">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
              <span className="text-[10px] uppercase tracking-[0.2em] text-white/50 font-mono">System Initialization</span>
            </div>
            <h1 className="text-2xl font-semibold tracking-tight">Setup Your Rigor</h1>
          </div>

          <AnimatePresence mode="wait">
            {step === 1 && (
              <motion.div key="step1" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-6">
                <div>
                  <label className="block text-[10px] uppercase tracking-wider text-white/40 mb-2 font-mono">Your Name</label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20" />
                    <input type="text" className="w-full bg-black/40 border border-white/10 rounded-xl py-3 pl-10 pr-4 focus:outline-none focus:border-red-500/50 transition-colors" placeholder="Enter name..." value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
                  </div>
                </div>
                <button onClick={() => setStep(2)} disabled={!formData.name} className="w-full bg-white text-black font-semibold py-3 rounded-xl hover:bg-white/90 transition-colors flex items-center justify-center gap-2 disabled:opacity-50">Continue <ChevronRight className="w-4 h-4" /></button>
              </motion.div>
            )}

            {step === 2 && (
              <motion.div key="step2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-6">
                <div>
                  <label className="block text-[10px] uppercase tracking-wider text-white/40 mb-2 font-mono">Exam Month</label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20" />
                    <input type="month" className="w-full bg-black/40 border border-white/10 rounded-xl py-3 pl-10 pr-4 focus:outline-none focus:border-red-500/50 transition-colors" value={formData.exam_month} onChange={e => setFormData({...formData, exam_month: e.target.value})} />
                  </div>
                </div>
                <div>
                  <label className="block text-[10px] uppercase tracking-wider text-white/40 mb-2 font-mono">Number of Subjects</label>
                  <div className="relative">
                    <BookOpen className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20" />
                    <input type="number" min="1" className="w-full bg-black/40 border border-white/10 rounded-xl py-3 pl-10 pr-4 focus:outline-none focus:border-red-500/50 transition-colors" value={formData.subject_count} onChange={e => setFormData({...formData, subject_count: parseInt(e.target.value)})} />
                  </div>
                </div>
                <div className="flex gap-3">
                  <button onClick={() => setStep(1)} className="flex-1 bg-white/5 text-white font-semibold py-3 rounded-xl hover:bg-white/10 transition-colors">Back</button>
                  <button onClick={() => setStep(3)} disabled={!formData.exam_month} className="flex-[2] bg-white text-black font-semibold py-3 rounded-xl hover:bg-white/90 transition-colors flex items-center justify-center gap-2 disabled:opacity-50">Continue <ChevronRight className="w-4 h-4" /></button>
                </div>
              </motion.div>
            )}

            {step === 3 && (
              <motion.div key="step3" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-6">
                <div>
                  <label className="block text-[10px] uppercase tracking-wider text-white/40 mb-2 font-mono">Daily Study Goal (Hours)</label>
                  <div className="relative">
                    <Clock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20" />
                    <input type="number" min="1" max="24" className="w-full bg-black/40 border border-white/10 rounded-xl py-3 pl-10 pr-4 focus:outline-none focus:border-red-500/50 transition-colors" value={formData.daily_goal_hours} onChange={e => setFormData({...formData, daily_goal_hours: parseInt(e.target.value)})} />
                  </div>
                </div>
                <div>
                  <label className="block text-[10px] uppercase tracking-wider text-white/40 mb-2 font-mono">Negative Motivation Message</label>
                  <div className="relative">
                    <AlertTriangle className="absolute left-3 top-3 w-4 h-4 text-white/20" />
                    <textarea className="w-full bg-black/40 border border-white/10 rounded-xl py-3 pl-10 pr-4 h-24 focus:outline-none focus:border-red-500/50 transition-colors resize-none" placeholder="e.g., 'If you waste this time, you'll be a failure.'" value={formData.negative_motivation} onChange={e => setFormData({...formData, negative_motivation: e.target.value})} />
                  </div>
                </div>
                <div className="flex gap-3">
                  <button onClick={() => setStep(2)} className="flex-1 bg-white/5 text-white font-semibold py-3 rounded-xl hover:bg-white/10 transition-colors">Back</button>
                  <button onClick={handleSaveSettings} disabled={!formData.negative_motivation} className="flex-[2] bg-red-600 text-white font-semibold py-3 rounded-xl hover:bg-red-500 transition-colors flex items-center justify-center gap-2 disabled:opacity-50">Initialize Rigor</button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen font-sans flex overflow-hidden transition-colors duration-300 ${settings.theme === 'light' ? 'bg-[#f8f9fa] text-slate-900' : 'bg-[#0a0a0b] text-white'}`}>
      {/* Sidebar */}
      <aside className={`w-64 border-r flex flex-col shrink-0 transition-colors duration-300 ${settings.theme === 'light' ? 'bg-white border-slate-200' : 'bg-[#0d0e11] border-white/5'}`}>
        <div className={`p-6 border-b transition-colors duration-300 ${settings.theme === 'light' ? 'border-slate-200' : 'border-white/5'}`}>
          <div className="flex items-center gap-3 mb-1">
            <div className="w-8 h-8 bg-red-600 rounded-lg flex items-center justify-center shadow-[0_0_15px_rgba(220,38,38,0.3)]">
              <Clock className="w-5 h-5 text-white" />
            </div>
            <h1 className="font-bold tracking-tight text-lg">ExamRigor</h1>
          </div>
          <p className={`text-[10px] font-mono uppercase tracking-widest transition-colors duration-300 ${settings.theme === 'light' ? 'text-slate-400' : 'text-white/40'}`}>Performance OS v1.0</p>
        </div>

        <nav className="flex-1 p-4 space-y-2">
          <NavItem 
            icon={<ListTodo className="w-4 h-4" />} 
            label="Daily Tasks" 
            active={view === 'tasks'} 
            onClick={() => setView('tasks')}
            theme={settings.theme}
          />
          <NavItem 
            icon={<TrendingUp className="w-4 h-4" />} 
            label="Analytics" 
            active={view === 'analytics'} 
            onClick={() => setView('analytics')}
            theme={settings.theme}
          />
          <NavItem 
            icon={<History className="w-4 h-4" />} 
            label="Benchmarks" 
            active={view === 'benchmarks'} 
            onClick={() => setView('benchmarks')}
            theme={settings.theme}
          />
          <NavItem 
            icon={<Settings className="w-4 h-4" />} 
            label="Settings" 
            active={view === 'settings'}
            onClick={() => setView('settings')}
            theme={settings.theme}
          />
        </nav>

        <div className={`p-4 border-t transition-colors duration-300 ${settings.theme === 'light' ? 'border-slate-200' : 'border-white/5'}`}>
          <div className={`rounded-xl p-4 border transition-colors duration-300 ${settings.theme === 'light' ? 'bg-slate-50 border-slate-200' : 'bg-white/5 border-white/5'}`}>
            <p className={`text-[10px] uppercase tracking-wider mb-1 font-mono transition-colors duration-300 ${settings.theme === 'light' ? 'text-slate-400' : 'text-white/30'}`}>Active User</p>
            <p className="font-medium text-sm truncate">{settings.name}</p>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0">
        <header className={`h-16 border-b backdrop-blur-xl flex items-center justify-between px-8 shrink-0 transition-colors duration-300 ${settings.theme === 'light' ? 'bg-white/80 border-slate-200' : 'bg-[#0d0e11]/50 border-white/5'}`}>
          <div className="flex items-center gap-8">
            <div className="flex flex-col">
              <span className={`text-[10px] uppercase tracking-wider font-mono transition-colors duration-300 ${settings.theme === 'light' ? 'text-slate-400' : 'text-white/30'}`}>System Status</span>
              <span className="text-sm font-medium text-emerald-500 flex items-center gap-1.5">
                <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
                Operational
              </span>
            </div>
            <div className={`h-8 w-px transition-colors duration-300 ${settings.theme === 'light' ? 'bg-slate-200' : 'bg-white/5'}`} />
            <div className="flex flex-col">
              <span className={`text-[10px] uppercase tracking-wider font-mono transition-colors duration-300 ${settings.theme === 'light' ? 'text-slate-400' : 'text-white/30'}`}>Backlog Risk</span>
              <span className={`text-sm font-medium flex items-center gap-2 ${parseFloat(calculateRemainingProductiveHours()) < 1 ? 'text-red-500' : (settings.theme === 'light' ? 'text-blue-600' : 'text-blue-400')}`}>
                {calculateRemainingProductiveHours()}h Remaining
                {parseFloat(calculateRemainingProductiveHours()) < 0.5 && (
                  <AlertTriangle className="w-3 h-3 animate-bounce" />
                )}
              </span>
            </div>
          </div>
          <div className="flex items-center gap-6">
             <button 
              onClick={toggleTheme}
              className={`p-2 rounded-lg transition-colors ${settings.theme === 'light' ? 'bg-slate-100 text-slate-600 hover:bg-slate-200' : 'bg-white/5 text-white/60 hover:bg-white/10'}`}
             >
               {settings.theme === 'light' ? <Clock className="w-4 h-4" /> : <Settings className="w-4 h-4" />}
             </button>
             <div className="text-right">
                <p className={`text-[10px] uppercase tracking-wider font-mono transition-colors duration-300 ${settings.theme === 'light' ? 'text-slate-400' : 'text-white/30'}`}>Exam Target</p>
                <p className="text-sm font-medium">{settings.exam_month}</p>
             </div>
          </div>
        </header>

        <div className="flex-1 p-8 overflow-y-auto">
          <div className="max-w-6xl mx-auto">
            {activeTask ? (
              <ActiveSession 
                task={activeTask} 
                timer={timer} 
                isOvertime={isOvertime} 
                benchmark={benchmarks[activeTask.name]}
                onStop={stopTask}
                formatTime={formatTime}
                theme={settings.theme}
              />
            ) : view === 'tasks' ? (
              <div className="space-y-8">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <StatCard label="Daily Goal" value={`${settings.daily_goal_hours}h`} sub="Target" icon={<Clock className="w-4 h-4 text-blue-400" />} theme={settings.theme} />
                  <StatCard label="Time Spent" value={formatTime(todayStats.total_seconds)} sub="Today" icon={<History className="w-4 h-4 text-purple-400" />} theme={settings.theme} />
                  <StatCard label="Overtime" value={todayStats.overtime_count.toString()} sub="Incidents" icon={<AlertTriangle className="w-4 h-4 text-red-400" />} theme={settings.theme} />
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {/* Core Study Tasks */}
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h2 className="text-lg font-semibold flex items-center gap-2">
                        <Brain className="w-5 h-5 text-red-500" /> Core Study
                      </h2>
                      <div className="flex items-center gap-2">
                        <button onClick={() => setShowLibrary(true)} className={`text-[10px] font-mono uppercase tracking-widest flex items-center gap-1 transition-colors ${settings.theme === 'light' ? 'text-slate-400 hover:text-slate-900' : 'text-white/30 hover:text-white'}`}>
                          <History className="w-3 h-3" /> Library
                        </button>
                      </div>
                    </div>
                    <div className="space-y-3">
                      {tasks.filter(t => t.category === 'core').map(task => (
                        <TaskItem key={task.daily_id} task={task} benchmark={benchmarks[task.name]} onStart={() => startTask(task)} onRemove={() => task.daily_id && removeFromToday(task.daily_id)} formatTime={formatTime} theme={settings.theme} />
                      ))}
                      <AddTaskButton category="core" onAdd={setNewTask} current={newTask} submit={handleAddTask} theme={settings.theme} />
                    </div>
                  </div>

                  {/* Life Tasks */}
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h2 className="text-lg font-semibold flex items-center gap-2">
                        <User className="w-5 h-5 text-blue-500" /> Life Tasks
                      </h2>
                    </div>
                    <div className="space-y-3">
                      {tasks.filter(t => t.category === 'life').map(task => (
                        <TaskItem key={task.daily_id} task={task} benchmark={benchmarks[task.name]} onStart={() => startTask(task)} onRemove={() => task.daily_id && removeFromToday(task.daily_id)} formatTime={formatTime} theme={settings.theme} />
                      ))}
                      <AddTaskButton category="life" onAdd={setNewTask} current={newTask} submit={handleAddTask} theme={settings.theme} />
                    </div>
                  </div>
                </div>
              </div>
            ) : view === 'analytics' ? (
              <AnalyticsView 
                weeklyStats={weeklyStats} 
                subjectStats={subjectStats} 
                timelineStats={timelineStats} 
                theme={settings.theme}
                formatTime={formatTime}
              />
            ) : view === 'benchmarks' ? (
              <BenchmarksView 
                benchmarks={Object.values(benchmarks)} 
                theme={settings.theme} 
                formatTime={formatTime} 
              />
            ) : (
              <SettingsView 
                formData={formData} 
                setFormData={setFormData} 
                onSave={handleSaveSettings} 
                theme={settings.theme} 
              />
            )}
          </div>
        </div>
      </main>

      {/* Modals */}
      <AnimatePresence>
        {showLibrary && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setShowLibrary(false)} className="absolute inset-0 bg-black/80 backdrop-blur-sm" />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }} 
              animate={{ scale: 1, opacity: 1 }} 
              exit={{ scale: 0.9, opacity: 0 }} 
              className={`relative border rounded-2xl p-8 max-w-lg w-full shadow-2xl transition-colors ${settings?.theme === 'light' ? 'bg-white border-slate-200 text-slate-900' : 'bg-[#1c1d21] border-white/10 text-white'}`}
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold tracking-tight">Task Library</h2>
                <button 
                  onClick={() => setShowLibrary(false)} 
                  className={`transition-colors ${settings?.theme === 'light' ? 'text-slate-400 hover:text-slate-900' : 'text-white/40 hover:text-white'}`}
                >
                  <XCircle className="w-5 h-5" />
                </button>
              </div>
              <div className="space-y-2 max-h-[60vh] overflow-y-auto pr-2 custom-scrollbar">
                {library.length === 0 && (
                  <p className={`text-center py-8 transition-colors ${settings?.theme === 'light' ? 'text-slate-400' : 'text-white/20'}`}>
                    No historical tasks found.
                  </p>
                )}
                {library.map(task => {
                  const isAdded = tasks.some(t => t.id === task.id);
                  return (
                    <div 
                      key={task.id} 
                      className={`rounded-xl p-4 flex items-center justify-between border transition-colors ${settings?.theme === 'light' ? 'bg-slate-50 border-slate-100' : 'bg-white/5 border-white/5'}`}
                    >
                      <div>
                        <p className="font-medium text-sm">{task.name}</p>
                        <p className={`text-[10px] uppercase tracking-wider font-mono transition-colors ${settings?.theme === 'light' ? 'text-slate-400' : 'text-white/30'}`}>
                          {task.category} • {task.type}
                        </p>
                      </div>
                      <button 
                        disabled={isAdded}
                        onClick={() => addToToday(task.id)}
                        className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                          isAdded 
                            ? 'bg-emerald-500/20 text-emerald-500 cursor-default' 
                            : settings?.theme === 'light' 
                              ? 'bg-slate-900 text-white hover:bg-slate-800' 
                              : 'bg-white text-black hover:bg-white/90'
                        }`}
                      >
                        {isAdded ? 'Added' : 'Add to Today'}
                      </button>
                    </div>
                  );
                })}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showOvertimeModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-black/80 backdrop-blur-sm" />
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} className="relative bg-[#1c1d21] border border-red-500/30 rounded-2xl p-8 max-w-md w-full shadow-[0_0_50px_rgba(220,38,38,0.2)]">
              <div className="flex items-center gap-3 text-red-500 mb-6">
                <AlertTriangle className="w-8 h-8" />
                <h2 className="text-2xl font-bold tracking-tight uppercase">Rigor Breach</h2>
              </div>
              
              <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-4 mb-6">
                <p className="text-sm text-red-200 italic font-serif leading-relaxed">"{settings.negative_motivation}"</p>
              </div>

              <div className="space-y-4">
                <p className="text-sm text-white/60">You exceeded the standard time. Provide a reason for this failure:</p>
                <textarea 
                  className="w-full bg-black/40 border border-white/10 rounded-xl py-3 px-4 h-24 focus:outline-none focus:border-red-500/50 transition-colors resize-none text-sm"
                  placeholder="Why did you waste time?"
                  value={overtimeReason}
                  onChange={e => setOvertimeReason(e.target.value)}
                />
                <button 
                  onClick={saveLog}
                  disabled={!overtimeReason}
                  className="w-full bg-red-600 text-white font-bold py-3 rounded-xl hover:bg-red-500 transition-colors disabled:opacity-50"
                >
                  LOG FAILURE & CONTINUE
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function NavItem({ icon, label, active = false, onClick, theme }: { icon: React.ReactNode, label: string, active?: boolean, onClick?: () => void, theme?: string }) {
  return (
    <button 
      onClick={onClick}
      className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
        active 
          ? (theme === 'light' ? 'bg-slate-100 text-slate-900 shadow-sm' : 'bg-white/10 text-white shadow-inner') 
          : (theme === 'light' ? 'text-slate-400 hover:text-slate-900 hover:bg-slate-50' : 'text-white/40 hover:text-white hover:bg-white/5')
      }`}
    >
      {icon}
      <span className="text-sm font-medium">{label}</span>
    </button>
  );
}

function StatCard({ label, value, sub, icon, theme }: { label: string, value: string, sub: string, icon: React.ReactNode, theme?: string }) {
  return (
    <div className={`border rounded-2xl p-5 transition-colors group ${theme === 'light' ? 'bg-white border-slate-200 hover:border-slate-300' : 'bg-[#1c1d21] border-white/5 hover:border-white/10'}`}>
      <div className="flex items-center justify-between mb-3">
        <span className={`text-[10px] uppercase tracking-widest font-mono transition-colors ${theme === 'light' ? 'text-slate-400 group-hover:text-slate-600' : 'text-white/30 group-hover:text-white/50'}`}>{label}</span>
        {icon}
      </div>
      <div className="flex items-baseline gap-2">
        <span className="text-2xl font-bold tracking-tight">{value}</span>
        <span className={`text-[10px] font-mono uppercase transition-colors ${theme === 'light' ? 'text-slate-300' : 'text-white/20'}`}>{sub}</span>
      </div>
    </div>
  );
}

interface TaskItemProps {
  task: Task;
  benchmark?: Benchmark;
  onStart: () => void;
  onRemove: () => void;
  formatTime: (s: number) => string;
  theme?: string;
}

const TaskItem: React.FC<TaskItemProps> = ({ task, benchmark, onStart, onRemove, formatTime, theme }) => {
  return (
    <div className={`border rounded-xl p-4 flex items-center justify-between group transition-all ${
      theme === 'light' 
        ? 'bg-white border-slate-200 hover:border-slate-300' 
        : 'bg-[#1c1d21] border-white/5 hover:border-white/10'
    } ${task.is_completed ? 'opacity-50 grayscale' : ''}`}>
      <div className="flex items-center gap-4">
        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${task.type === 'standard' ? 'bg-red-500/10 text-red-500' : 'bg-blue-500/10 text-blue-500'}`}>
          {task.is_completed ? <CheckCircle2 className="w-5 h-5 text-emerald-500" /> : (task.type === 'standard' ? <Clock className="w-5 h-5" /> : <TrendingUp className="w-5 h-5" />)}
        </div>
        <div>
          <h3 className={`font-medium text-sm ${task.is_completed ? 'line-through text-slate-400' : ''}`}>{task.name}</h3>
          <div className="flex items-center gap-3 mt-1">
            <span className={`text-[10px] font-mono uppercase tracking-wider ${theme === 'light' ? 'text-slate-400' : 'text-white/30'}`}>{task.type}</span>
            {benchmark && (
              <span className="text-[10px] font-mono text-emerald-500 uppercase tracking-wider">Best: {formatTime(benchmark.best_seconds)}</span>
            )}
          </div>
        </div>
      </div>
      <div className="flex items-center gap-2">
        {!task.is_completed && (
          <button onClick={onStart} className={`p-2 rounded-lg transition-all opacity-0 group-hover:opacity-100 ${theme === 'light' ? 'bg-slate-100 hover:bg-slate-900 text-slate-600 hover:text-white' : 'bg-white/5 hover:bg-white text-white hover:text-black'}`}>
            <Play className="w-4 h-4 fill-current" />
          </button>
        )}
        <button onClick={onRemove} className={`p-2 rounded-lg transition-all opacity-0 group-hover:opacity-100 ${theme === 'light' ? 'bg-slate-100 hover:bg-red-500 text-slate-600 hover:text-white' : 'bg-white/5 hover:bg-red-500 text-white'}`}>
          <XCircle className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

interface AddTaskButtonProps {
  category: 'core' | 'life';
  onAdd: (task: any) => void;
  current: any;
  submit: () => void;
  theme?: string;
}

const AddTaskButton: React.FC<AddTaskButtonProps> = ({ category, onAdd, current, submit, theme }) => {
  const [isAdding, setIsAdding] = useState(false);

  if (!isAdding) {
    return (
      <button 
        onClick={() => {
          setIsAdding(true);
          onAdd({ ...current, category });
        }}
        className={`w-full border border-dashed rounded-xl py-4 transition-all flex items-center justify-center gap-2 text-sm font-medium ${
          theme === 'light' 
            ? 'border-slate-200 text-slate-400 hover:text-slate-600 hover:border-slate-300' 
            : 'border-white/10 text-white/20 hover:text-white/40 hover:border-white/20'
        }`}
      >
        <Plus className="w-4 h-4" /> Add Task
      </button>
    );
  }

  return (
    <div className={`border rounded-xl p-4 space-y-4 ${theme === 'light' ? 'bg-white border-slate-300 shadow-sm' : 'bg-[#1c1d21] border-white/20'}`}>
      <input 
        autoFocus
        className={`w-full border rounded-lg py-2 px-3 text-sm focus:outline-none transition-colors ${
          theme === 'light' ? 'bg-slate-50 border-slate-200 focus:border-slate-400' : 'bg-black/40 border-white/10 focus:border-white/30'
        }`}
        placeholder="Task name..."
        value={current.name}
        onChange={e => onAdd({ ...current, name: e.target.value })}
      />
      <div className="flex gap-2">
        <select 
          className={`flex-1 border rounded-lg py-2 px-3 text-xs focus:outline-none transition-colors ${
            theme === 'light' ? 'bg-slate-50 border-slate-200' : 'bg-black/40 border-white/10'
          }`}
          value={current.type}
          onChange={e => onAdd({ ...current, type: e.target.value })}
        >
          <option value="normal">Normal (Benchmark)</option>
          <option value="standard">Standard (Timer)</option>
        </select>
        {current.type === 'standard' && (
          <input 
            type="number"
            className={`w-20 border rounded-lg py-2 px-3 text-xs focus:outline-none transition-colors ${
              theme === 'light' ? 'bg-slate-50 border-slate-200' : 'bg-black/40 border-white/10'
            }`}
            placeholder="Min"
            value={current.standard_minutes}
            onChange={e => onAdd({ ...current, standard_minutes: parseInt(e.target.value) })}
          />
        )}
      </div>
      <div className="flex gap-2">
        <button onClick={() => setIsAdding(false)} className={`flex-1 text-xs font-medium transition-colors ${theme === 'light' ? 'text-slate-400 hover:text-slate-900' : 'text-white/40 hover:text-white'}`}>Cancel</button>
        <button onClick={() => { submit(); setIsAdding(false); }} className={`flex-1 text-xs font-bold py-2 rounded-lg transition-colors ${theme === 'light' ? 'bg-slate-900 text-white hover:bg-slate-800' : 'bg-white text-black hover:bg-white/90'}`}>Add Task</button>
      </div>
    </div>
  );
}

interface ActiveSessionProps {
  task: Task;
  timer: number;
  isOvertime: boolean;
  benchmark?: Benchmark;
  onStop: () => void;
  formatTime: (s: number) => string;
  theme?: string;
}

const ActiveSession: React.FC<ActiveSessionProps> = ({ task, timer, isOvertime, benchmark, onStop, formatTime, theme }) => {
  const diff = benchmark ? timer - benchmark.best_seconds : 0;
  
  return (
    <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className={`max-w-2xl mx-auto border rounded-3xl p-12 text-center shadow-2xl relative overflow-hidden transition-colors duration-300 ${
      theme === 'light' ? 'bg-white border-slate-200' : 'bg-[#1c1d21] border-white/10'
    }`}>
      {isOvertime && (
        <div className="absolute inset-0 bg-red-500/5 animate-pulse pointer-events-none" />
      )}
      
      <div className="mb-8">
        <span className={`text-[10px] font-mono uppercase tracking-[0.3em] px-3 py-1 rounded-full border ${isOvertime ? 'border-red-500 text-red-500 bg-red-500/10' : 'border-emerald-500 text-emerald-500 bg-emerald-500/10'}`}>
          {isOvertime ? 'Overtime Breach' : 'Session Active'}
        </span>
        <h2 className="text-4xl font-bold tracking-tight mt-6 mb-2">{task.name}</h2>
        <p className={`text-sm font-mono uppercase tracking-widest transition-colors ${theme === 'light' ? 'text-slate-400' : 'text-white/40'}`}>{task.category} Task</p>
      </div>

      <div className="text-8xl font-black tracking-tighter font-mono mb-6 tabular-nums">
        {formatTime(timer)}
      </div>

      {benchmark && (
        <div className="mb-12 flex items-center justify-center gap-4">
          <div className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-mono uppercase tracking-wider ${diff > 0 ? 'bg-red-500/10 text-red-500' : 'bg-emerald-500/10 text-emerald-500'}`}>
            {diff > 0 ? <TrendingUp className="w-3 h-3 rotate-45" /> : <TrendingUp className="w-3 h-3 -rotate-45" />}
            {diff > 0 ? '+' : ''}{formatTime(Math.abs(diff))} vs Best
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 gap-6 mb-12">
        <div className={`rounded-2xl p-4 border transition-colors ${theme === 'light' ? 'bg-slate-50 border-slate-100' : 'bg-black/40 border-white/5'}`}>
          <p className={`text-[10px] uppercase tracking-wider mb-1 font-mono transition-colors ${theme === 'light' ? 'text-slate-400' : 'text-white/30'}`}>Benchmark</p>
          <p className="text-lg font-bold">{benchmark ? formatTime(benchmark.best_seconds) : '--:--'}</p>
        </div>
        <div className={`rounded-2xl p-4 border transition-colors ${theme === 'light' ? 'bg-slate-50 border-slate-100' : 'bg-black/40 border-white/5'}`}>
          <p className={`text-[10px] uppercase tracking-wider mb-1 font-mono transition-colors ${theme === 'light' ? 'text-slate-400' : 'text-white/30'}`}>Standard</p>
          <p className="text-lg font-bold">{task.standard_minutes ? `${task.standard_minutes}m` : 'None'}</p>
        </div>
      </div>

      <button 
        onClick={onStop}
        className={`group relative w-24 h-24 rounded-full flex items-center justify-center hover:scale-110 transition-all active:scale-95 shadow-xl mx-auto ${
          theme === 'light' ? 'bg-slate-900 text-white shadow-slate-200' : 'bg-white text-black shadow-[0_0_30px_rgba(255,255,255,0.2)]'
        }`}
      >
        <Square className="w-8 h-8 fill-current" />
        <span className={`absolute -bottom-8 text-[10px] font-mono uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity ${theme === 'light' ? 'text-slate-400' : 'text-white/40'}`}>Press Enter to Stop</span>
      </button>

      {isOvertime && (
        <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} className="mt-12 flex items-center justify-center gap-2 text-red-500 font-mono text-xs animate-bounce">
          <AlertTriangle className="w-4 h-4" /> WARNING: RIGOR BREACH DETECTED
        </motion.div>
      )}
    </motion.div>
  );
}

const AnalyticsView: React.FC<{ weeklyStats: any[], subjectStats: any[], timelineStats: any[], theme?: string, formatTime: (s: number) => string }> = ({ weeklyStats, subjectStats, timelineStats, theme, formatTime }) => {
  const COLORS = ['#ef4444', '#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899'];
  
  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Weekly Trend */}
        <div className={`border rounded-2xl p-6 transition-colors ${theme === 'light' ? 'bg-white border-slate-200' : 'bg-[#1c1d21] border-white/5'}`}>
          <h3 className="text-sm font-bold uppercase tracking-widest mb-6 font-mono">Weekly Performance Trend</h3>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={weeklyStats}>
                <CartesianGrid strokeDasharray="3 3" stroke={theme === 'light' ? '#e2e8f0' : '#ffffff10'} />
                <XAxis dataKey="date" stroke={theme === 'light' ? '#64748b' : '#ffffff40'} fontSize={10} />
                <YAxis stroke={theme === 'light' ? '#64748b' : '#ffffff40'} fontSize={10} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: theme === 'light' ? '#fff' : '#1c1d21', 
                    borderColor: theme === 'light' ? '#e2e8f0' : '#ffffff10',
                    color: theme === 'light' ? '#0f172a' : '#fff'
                  }} 
                />
                <Bar dataKey="total_seconds" name="Study Time" fill="#ef4444" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Subject Distribution */}
        <div className={`border rounded-2xl p-6 transition-colors ${theme === 'light' ? 'bg-white border-slate-200' : 'bg-[#1c1d21] border-white/5'}`}>
          <h3 className="text-sm font-bold uppercase tracking-widest mb-6 font-mono">Subject Distribution</h3>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={subjectStats}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="total_seconds"
                  nameKey="subject"
                >
                  {subjectStats.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: theme === 'light' ? '#fff' : '#1c1d21', 
                    borderColor: theme === 'light' ? '#e2e8f0' : '#ffffff10',
                    color: theme === 'light' ? '#0f172a' : '#fff'
                  }} 
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Time Map Canvas */}
      <div className={`border rounded-2xl p-6 transition-colors ${theme === 'light' ? 'bg-white border-slate-200' : 'bg-[#1c1d21] border-white/5'}`}>
        <h3 className="text-sm font-bold uppercase tracking-widest mb-6 font-mono">Daily Time Map (Visual Timeline)</h3>
        <TimeMapCanvas timeline={timelineStats} theme={theme} />
      </div>
    </div>
  );
}

const TimeMapCanvas: React.FC<{ timeline: any[], theme?: string }> = ({ timeline, theme }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas dimensions
    const width = canvas.offsetWidth;
    const height = 120;
    canvas.width = width;
    canvas.height = height;

    // Clear canvas
    ctx.clearRect(0, 0, width, height);

    // Draw background grid
    ctx.strokeStyle = theme === 'light' ? '#e2e8f0' : '#ffffff10';
    ctx.lineWidth = 1;
    for (let i = 0; i < 24; i++) {
      const x = (i / 24) * width;
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
      
      ctx.fillStyle = theme === 'light' ? '#94a3b8' : '#ffffff30';
      ctx.font = '8px monospace';
      ctx.fillText(`${i}h`, x + 5, height - 5);
    }

    // Draw timeline blocks
    let currentX = 0;
    const totalSecondsInDay = 24 * 3600;
    
    timeline.forEach((log, index) => {
      const blockWidth = (log.duration_seconds / totalSecondsInDay) * width * 10; // Scaled for visibility
      const blockHeight = log.category === 'core' ? 40 : 20;
      const y = log.category === 'core' ? 20 : 70;
      
      ctx.fillStyle = log.category === 'core' ? '#ef4444' : '#3b82f6';
      ctx.globalAlpha = 0.8;
      ctx.fillRect(currentX, y, blockWidth, blockHeight);
      
      // Label
      if (blockWidth > 40) {
        ctx.fillStyle = '#fff';
        ctx.globalAlpha = 1;
        ctx.font = '9px sans-serif';
        ctx.fillText(log.task_name.substring(0, 10), currentX + 5, y + 15);
      }
      
      currentX += blockWidth + 5;
    });

  }, [timeline, theme]);

  return (
    <div className="w-full overflow-x-auto">
      <canvas 
        ref={canvasRef} 
        className="w-full h-[120px] rounded-lg"
        style={{ minWidth: '800px' }}
      />
    </div>
  );
}

const SettingsView: React.FC<{ formData: UserSettings, setFormData: (s: UserSettings) => void, onSave: () => void, theme?: string }> = ({ formData, setFormData, onSave, theme }) => {
  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold tracking-tight">System Settings</h2>
        <button 
          onClick={onSave}
          className={`px-6 py-2 rounded-xl font-bold transition-all ${theme === 'light' ? 'bg-slate-900 text-white hover:bg-slate-800' : 'bg-white text-black hover:bg-white/90'}`}
        >
          Save Changes
        </button>
      </div>

      <div className={`border rounded-2xl p-8 space-y-6 transition-colors ${theme === 'light' ? 'bg-white border-slate-200' : 'bg-[#1c1d21] border-white/5'}`}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className={`block text-[10px] uppercase tracking-wider mb-2 font-mono transition-colors ${theme === 'light' ? 'text-slate-400' : 'text-white/40'}`}>User Name</label>
            <input 
              type="text" 
              className={`w-full border rounded-xl py-3 px-4 focus:outline-none transition-colors ${theme === 'light' ? 'bg-slate-50 border-slate-200 focus:border-slate-400' : 'bg-black/40 border-white/10 focus:border-white/30'}`}
              value={formData.name} 
              onChange={e => setFormData({...formData, name: e.target.value})} 
            />
          </div>
          <div>
            <label className={`block text-[10px] uppercase tracking-wider mb-2 font-mono transition-colors ${theme === 'light' ? 'text-slate-400' : 'text-white/40'}`}>Exam Month</label>
            <input 
              type="month" 
              className={`w-full border rounded-xl py-3 px-4 focus:outline-none transition-colors ${theme === 'light' ? 'bg-slate-50 border-slate-200 focus:border-slate-400' : 'bg-black/40 border-white/10 focus:border-white/30'}`}
              value={formData.exam_month} 
              onChange={e => setFormData({...formData, exam_month: e.target.value})} 
            />
          </div>
          <div>
            <label className={`block text-[10px] uppercase tracking-wider mb-2 font-mono transition-colors ${theme === 'light' ? 'text-slate-400' : 'text-white/40'}`}>Subject Count</label>
            <input 
              type="number" 
              className={`w-full border rounded-xl py-3 px-4 focus:outline-none transition-colors ${theme === 'light' ? 'bg-slate-50 border-slate-200 focus:border-slate-400' : 'bg-black/40 border-white/10 focus:border-white/30'}`}
              value={formData.subject_count} 
              onChange={e => setFormData({...formData, subject_count: parseInt(e.target.value)})} 
            />
          </div>
          <div>
            <label className={`block text-[10px] uppercase tracking-wider mb-2 font-mono transition-colors ${theme === 'light' ? 'text-slate-400' : 'text-white/40'}`}>Daily Goal (Hours)</label>
            <input 
              type="number" 
              className={`w-full border rounded-xl py-3 px-4 focus:outline-none transition-colors ${theme === 'light' ? 'bg-slate-50 border-slate-200 focus:border-slate-400' : 'bg-black/40 border-white/10 focus:border-white/30'}`}
              value={formData.daily_goal_hours} 
              onChange={e => setFormData({...formData, daily_goal_hours: parseInt(e.target.value)})} 
            />
          </div>
        </div>

        <div>
          <label className={`block text-[10px] uppercase tracking-wider mb-2 font-mono transition-colors ${theme === 'light' ? 'text-slate-400' : 'text-white/40'}`}>Negative Motivation</label>
          <textarea 
            className={`w-full border rounded-xl py-3 px-4 h-24 focus:outline-none transition-colors resize-none ${theme === 'light' ? 'bg-slate-50 border-slate-200 focus:border-slate-400' : 'bg-black/40 border-white/10 focus:border-white/30'}`}
            value={formData.negative_motivation} 
            onChange={e => setFormData({...formData, negative_motivation: e.target.value})} 
          />
        </div>
      </div>
    </div>
  );
}

const BenchmarksView: React.FC<{ benchmarks: Benchmark[], theme?: string, formatTime: (s: number) => string }> = ({ benchmarks, theme, formatTime }) => {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold tracking-tight">Performance Benchmarks</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {benchmarks.map(b => (
          <div key={b.task_name} className={`border rounded-2xl p-6 transition-colors ${theme === 'light' ? 'bg-white border-slate-200' : 'bg-[#1c1d21] border-white/5'}`}>
            <h3 className="font-bold text-lg mb-4">{b.task_name}</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className={`text-[10px] uppercase tracking-wider font-mono ${theme === 'light' ? 'text-slate-400' : 'text-white/30'}`}>Best Time</span>
                <span className="font-mono font-bold text-emerald-500">{formatTime(b.best_seconds)}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className={`text-[10px] uppercase tracking-wider font-mono ${theme === 'light' ? 'text-slate-400' : 'text-white/30'}`}>Last Session</span>
                <span className="font-mono font-bold">{formatTime(b.last_seconds)}</span>
              </div>
              <div className={`h-1 w-full rounded-full overflow-hidden ${theme === 'light' ? 'bg-slate-100' : 'bg-white/5'}`}>
                <div 
                  className="h-full bg-emerald-500" 
                  style={{ width: `${Math.min(100, (b.best_seconds / b.last_seconds) * 100)}%` }} 
                />
              </div>
            </div>
          </div>
        ))}
        {benchmarks.length === 0 && (
          <div className="col-span-full py-20 text-center">
            <History className={`w-12 h-12 mx-auto mb-4 opacity-20 ${theme === 'light' ? 'text-slate-900' : 'text-white'}`} />
            <p className={`text-sm font-mono uppercase tracking-widest ${theme === 'light' ? 'text-slate-400' : 'text-white/30'}`}>No benchmarks recorded yet.</p>
          </div>
        )}
      </div>
    </div>
  );
}
